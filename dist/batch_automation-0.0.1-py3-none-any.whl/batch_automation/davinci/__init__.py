"""Top-level package for DaVinci Resolve API."""

__author__ = """Georgi Marinov"""
__email__ = 'georgi.marinow@gmail.com'
__version__ = '0.1.0'
